<!-- GBD/src/components/icon/Class.vue -->
<template>
    <svg class="svg-node" viewBox="0 0 32 32">
      <g transform="translate(0.5,0.5)" style="visibility: visible">
        <rect
          x="2"
          y="2"
          width="28"
          height="28"
          fill="#ffffff"
          stroke="#000000"
          stroke-width="1.3"
          pointer-events="all"
        ></rect>
        <line x1="2" y1="10" x2="30" y2="10" stroke="#000000" stroke-width="1.3"></line>
        <line x1="2" y1="20" x2="30" y2="20" stroke="#000000" stroke-width="1.3"></line>
      </g>
    </svg>
  </template>
  
  <script>
  export default {
  }
  </script>