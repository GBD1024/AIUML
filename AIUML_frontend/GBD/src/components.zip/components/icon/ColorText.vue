<template>
  <svg class="icon" viewBox="0 0 1024 1024" :width="size" :height="size">
    <path d="M512 725.333333a128 128 0 1 1 0 256 128 128 0 0 1 0-256zM469.333333 85.333333L234.666667 682.666667h96l47.786666-128h266.666667l47.786667 128h96L554.666667 85.333333h-85.333334z m-58.88 384L512 199.253333 613.546667 469.333333H410.453333z" p-id="4479"></path>
  </svg>
</template>

<script>
export default {
  props: {
    size: {
      default: '24'
    }
  }
}
</script>
