// 元素属性右侧面板默认属性
export const defatuleStyle = {
  backgroundColor: '', // 填充色
  gradientColor: '', // 渐变色
  borderType: 0, // 边框类型
  borderColor: '', // 填充颜色
  borderWidth: 1, // 边框宽度
  borderStyle: '', // 边框类型
  fontSize: 12, // 文本大小
  fontColor: '', // 文本颜色
  fontWeight: '' // 文本加粗
}
