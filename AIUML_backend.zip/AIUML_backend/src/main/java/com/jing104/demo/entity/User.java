package com.jing104.demo.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import lombok.NonNull;
import org.springframework.validation.annotation.Validated;

import java.sql.Timestamp;
import java.time.LocalDateTime;

@Data
@Validated
public class User {
    @NotNull
    private int id;
    @NotEmpty
    @Email
    private String user_name;
    @JsonIgnore//Springmvc把对象数据转化为json时，忽略password
    private String password;
    @NotEmpty
    @Pattern(regexp = "^\\S{1,16}$")
    private String nickname;
    private String user_pic;
    private LocalDateTime created_time;
    private LocalDateTime updated_time;
    private boolean del;

}
