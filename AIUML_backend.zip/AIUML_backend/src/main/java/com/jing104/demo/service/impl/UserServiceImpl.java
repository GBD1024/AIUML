package com.jing104.demo.service.impl;

import com.jing104.demo.dao.IUserDao;
import com.jing104.demo.entity.Result;
import com.jing104.demo.entity.User;
import com.jing104.demo.service.IUserService;
import com.jing104.demo.util.JwtUtil;
import com.jing104.demo.util.Md5Util;
import com.jing104.demo.util.ThreadLocalUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Service
public class UserServiceImpl implements IUserService {
    @Autowired
    private IUserDao userDao;
    @Autowired
    private JavaMailSender mailSender;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;
    @Value("${spring.mail.username}")
    private String fromEmail;


    @Override
    public String sendRandomVerificationCode(String email) {
        String code = generateRandomCode();
        updateVerificationCode(email, code, "register:");
        sendEmail(email, code, "您的注册验证码");
        return code;
    }
    @Override
    public String sendRandomUpdatePwdCode(String email) {
        String code = generateRandomCode();
        updateVerificationCode(email, code, "updatePwd:");
        sendEmail(email, code, "您的更改密码验证码");
        return code;
    }

    private void updateVerificationCode(String email, String code, String prefix) {
        String key = prefix + email;
        ValueOperations<String, String> operations = stringRedisTemplate.opsForValue();
        operations.getOperations().delete(key);
        operations.set(key, code, 2, TimeUnit.MINUTES);
    }

    private String generateRandomCode() {
        return String.valueOf(new Random().nextInt(900000) + 100000);
    }

    private void sendEmail(String toEmail, String code, String subject) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(fromEmail);
        message.setTo(toEmail);
        message.setSubject("图灵智绘");
        message.setText(subject + ": " + code + "\n验证码有效期为2分钟，请及时正确填写。\n请勿将验证码告诉他人，祝您生活愉快。");
        mailSender.send(message);
    }

    @Override
    public boolean isCodeValid(String email, String code, String prefix) {
        String key = prefix + email;
        ValueOperations<String, String> operations = stringRedisTemplate.opsForValue();
        String nowCode = operations.get(key);
        return nowCode != null && nowCode.equals(code);
    }

    @Override
    public void register(String user_name, String password) {
        String md5String = Md5Util.getMD5String(password);
        userDao.register(user_name, md5String);
        User u = userDao.findByUsername(user_name);
        String randomNickId= UUID.randomUUID().toString().substring(0, 8);
        int id = u.getId();
        userDao.updateNickname("User_" + randomNickId, id);
    }

    @Override
    public User findByUsername(String user_name) {
        return userDao.findByUsername(user_name);
    }

    @Override
    public Result login(String user_name, String password) {
        User u = userDao.findByUsername(user_name);
        String md5String = Md5Util.getMD5String(password);

        if (u == null) {
            return Result.error("用户名错误或不存在");
        } else if (!u.getPassword().equals(md5String)) {
            return Result.error("密码错误");
        } else {
            // 删除旧的令牌（如果存在）
            String oldTokenKey = "user:token:" + u.getId();
            String oldToken = (String) stringRedisTemplate.opsForValue().get(oldTokenKey);
            if (oldToken != null) {
                stringRedisTemplate.delete(oldToken);
            }

            // 生成新的令牌
            Map<String, Object> claims = new HashMap<>();
            claims.put("id", u.getId());
            claims.put("user_name", u.getUser_name());
            String token = JwtUtil.genToken(claims);

            // 将新的令牌储存
            ValueOperations<String, String> operations = stringRedisTemplate.opsForValue();
            operations.set(token, String.valueOf(u.getId()), 24, TimeUnit.HOURS);
            operations.set(oldTokenKey, token, 24, TimeUnit.HOURS);

            return Result.success(token);
        }
    }


    /*public Result login(String user_name, String password)
    {
        User u =userDao.findByUsername(user_name);
        String md5String= Md5Util.getMD5String(password);
        if(u==null)
        {
            return Result.error("用户名错误或不存在");

        }
        else if(!u.getPassword().equals(md5String)){
            return Result.error("密码错误");
        }
        else{
            Map<String,Object> claims= new HashMap<>();
            claims.put("id",u.getId());
            claims.put("user_name",u.getUser_name());
            String token= JwtUtil.genToken(claims);
            //将令牌储存
            ValueOperations<String,String> operations =stringRedisTemplate.opsForValue();
            operations.set(token,token,24, TimeUnit.HOURS);
            return Result.success(token);
        }
    }*/

    @Override
    public Result updateNickname(Map<String, String> params) {
        String newNickname=params.get("nickname");

        Map<String,Object> claimsMap=ThreadLocalUtil.get();
        Integer id= (Integer) claimsMap.get("id");
        String user_name= (String) claimsMap.get("user_name");
        User u=userDao.findByUsername(user_name);
        if(u==null)
        {
            return Result.error("用户名错误或不存在");
        }
        if(u.getNickname().equals(newNickname))
        {
            return Result.error("新昵称与旧昵称相同");
        }
        userDao.updateNickname(newNickname,id);
        return  Result.success();
    }

    @Override
    public void deleteAccount(String token) {
        Boolean hasKey = stringRedisTemplate.hasKey(token);

        if (Boolean.TRUE.equals(hasKey)) {
            Map<String,Object> claimsMap=ThreadLocalUtil.get();
            Integer id= (Integer) claimsMap.get("id");

            if (id != null) {
                // 删除存储的令牌
                stringRedisTemplate.delete(token);
                stringRedisTemplate.delete("user:token:" + id);
                userDao.deleteAccount(id);
            }
        }



    }

    @Override
    public void updateAvatar(String avatarUrl) {
        Map<String,Object> claimsMap=ThreadLocalUtil.get();
        Integer id= (Integer) claimsMap.get("id");
        userDao.updateAvatar(avatarUrl,id);
    }

    @Override
    public Result updatePwd(Map<String, String> params, String token) {
        // 参数校验
        String oldPwd = params.get("old_pwd");
        String newPwd = params.get("new_pwd");
        String rePwd = params.get("re_pwd");
        if (!StringUtils.hasLength(oldPwd) || !StringUtils.hasLength(newPwd) || !StringUtils.hasLength(rePwd)) {
            return Result.error("有参数未填写");
        }

        // 获取当前用户信息
        Map<String, Object> claimsMap = ThreadLocalUtil.get();
        String user_name = (String) claimsMap.get("user_name");
        User loginUser = userDao.findByUsername(user_name);

        // 验证旧密码
        if (!loginUser.getPassword().equals(Md5Util.getMD5String(oldPwd))) {
            return Result.error("原密码不正确");
        }

        // 检查新密码一致性
        if (!rePwd.equals(newPwd)) {
            return Result.error("两次填写的新密码不一致");
        }

        // 更新密码
        String md5NewPwd = Md5Util.getMD5String(newPwd);
        Integer id = (Integer) claimsMap.get("id");
        userDao.updatePwd(md5NewPwd, id);

        // 删除旧令牌
        ValueOperations<String, String> operations = stringRedisTemplate.opsForValue();
        operations.getOperations().delete(token);

        // 可选：生成新的令牌
        /*Map<String, Object> newClaims = new HashMap<>();
        newClaims.put("id", loginUser.getId());
        newClaims.put("user_name", loginUser.getUser_name());
        String newToken = JwtUtil.genToken(newClaims);
        operations.set(newToken, String.valueOf(loginUser.getId()), 24, TimeUnit.HOURS);
        operations.set("user:token:" + loginUser.getId(), newToken, 24, TimeUnit.HOURS);
        */
        return Result.success();
    }

    @Override
    public Result logout(String token) {
        if (token == null || token.isEmpty()) {
            return Result.error("无效的令牌");
        }

        // 检查令牌是否存在
        Boolean hasKey = stringRedisTemplate.hasKey(token);

        if (Boolean.TRUE.equals(hasKey)) {
            Map<String,Object> claimsMap=ThreadLocalUtil.get();
            Integer id= (Integer) claimsMap.get("id");

            if (id != null) {
                // 删除存储的令牌
                stringRedisTemplate.delete(token);
                stringRedisTemplate.delete("user:token:" + id);
                return Result.success();
            } else {
                return Result.error("令牌无效或已过期");
            }
        } else {
            return Result.error("令牌无效或已过期");
        }
    }

    @Override
    public Result NewupdatePwd(Map<String, String> params, String token) {
        String email = params.get("userId");
        String inputCode = params.get("verifyCode");
        String newPassword = params.get("pass");
        String repeatNewPassword = params.get("checkPass");

        // 验证参数
        if (!StringUtils.hasText(email) || !StringUtils.hasText(inputCode) || !StringUtils.hasText(newPassword) || !StringUtils.hasText(repeatNewPassword)) {
            return Result.error("参数不完整");
        }
        if (!newPassword.equals(repeatNewPassword)) {
            return Result.error("新密码和重复新密码不一致");
        }

        // 验证 token 并获取 user_id 和 user_name
        Map<String, Object> claims = JwtUtil.parseToken(token);
        if (claims == null) {
            return Result.error("无效的令牌");
        }
        Integer userId = (Integer) claims.get("id");
        String userName = String.valueOf(claims.get("user_name"));
        if (!userName.equals(email)) {
            return Result.error("邮箱不匹配");
        }

        // 验证验证码
        if (!isCodeValid(email, inputCode, "updatePwd:")) {
            return Result.error("验证码无效或已过期");
        }

        // 更新密码
        User user = userDao.findByUsername(userName);
        if (user == null) {
            return Result.error("用户不存在");
        }
        String md5NewPassword = Md5Util.getMD5String(newPassword);
        userDao.updatePwd(md5NewPassword, userId);

        // 使旧的验证码失效
        String codeKey = "updatePwd:" + email;
        stringRedisTemplate.delete(codeKey);

        // 删除旧令牌
        ValueOperations<String, String> operations = stringRedisTemplate.opsForValue();
        operations.getOperations().delete(token);
        return Result.success();
    }
    /*public Result logout(String token) {
        if (token == null || token.isEmpty()) {
            return Result.error("无效的令牌");
        }

        // 从 Redis 中删除令牌
        Boolean hasKey = stringRedisTemplate.hasKey(token);

        if (Boolean.TRUE.equals(hasKey)) {
            stringRedisTemplate.delete(token);
            return Result.success();
        } else {
            return Result.error("令牌无效或已过期");
        }
    }*/

}
