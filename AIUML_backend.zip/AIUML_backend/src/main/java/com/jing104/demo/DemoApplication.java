package com.jing104.demo;

import jakarta.annotation.PostConstruct;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.TimeZone;

@SpringBootApplication
@MapperScan("com.jing104.demo.dao.mapper")
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@PostConstruct
	public void init() {
		// 设置默认时区为北京时间
		TimeZone.setDefault(TimeZone.getTimeZone("Asia/Shanghai"));
		// 打印当前默认时区
		System.out.println("当前默认时区是: " + TimeZone.getDefault().getID());

	}
}
