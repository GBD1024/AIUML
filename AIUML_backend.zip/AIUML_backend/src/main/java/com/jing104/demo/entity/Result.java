package com.jing104.demo.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Result<T> {
    private int code;
    private String message;
    private T info;


    public static <E> Result<E> success(E info)
    {
        return new Result<>(0,"操作成功",info);
    }
    public static Result success()
    {
        return new Result(0,"操作成功",null);
    }
    public static Result error(String message)
    {
        return new Result(1,message,null);
    }
    public static <E> Result<E> error(E info)
    {
        return new Result<>(0,"操作失败",info);
    }

}
