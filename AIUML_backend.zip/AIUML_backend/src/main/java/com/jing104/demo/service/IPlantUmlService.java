package com.jing104.demo.service;

import java.io.IOException;

public interface IPlantUmlService {
    byte[] generateImage(String source) throws IOException;
}
