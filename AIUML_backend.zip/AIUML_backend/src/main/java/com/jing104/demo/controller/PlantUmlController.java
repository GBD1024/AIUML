package com.jing104.demo.controller;

import com.jing104.demo.service.IPlantUmlService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/plantuml")
public class PlantUmlController {

    private final IPlantUmlService plantUmlService;

    // 构造函数注入服务
    public PlantUmlController(IPlantUmlService plantUmlService) {
        this.plantUmlService = plantUmlService;
    }

    @PostMapping(value = "/generate", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<byte[]> generateImage(@RequestBody Map<String, String> requestBody) {
        try {
            String source = requestBody.get("source");
            byte[] imageBytes = plantUmlService.generateImage(source);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.IMAGE_PNG);
            return new ResponseEntity<>(imageBytes, headers, HttpStatus.OK);
        } catch (Exception e) {
            // 记录异常日志
            // 使用更合适的日志记录方法，例如通过SLF4J或Logback
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}