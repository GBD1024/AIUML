package com.jing104.demo.dao;

import com.jing104.demo.entity.User;
import org.springframework.stereotype.Repository;


public interface IUserDao {
    void register(String user_name, String md5String);

    User findByUsername(String user_name);

    void updateNickname(String newNickname,Integer id);

    void deleteAccount(int id);

    void updateAvatar(String avatarUrl, Integer id);

    void updatePwd(String newPwd,Integer id);
}
