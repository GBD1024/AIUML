package com.jing104.demo.dao.mapper;

import com.jing104.demo.entity.User;

public interface UserMapper {
    void add(String user_name, String password);

    User findByUsername(String user_name);

    void updateNickname(String newNickname,Integer id);

    void deleteAccount(int id);

    void updateAvatar(String avatarUrl, Integer id);

    void updatePwd(String newPwd,Integer id);
}
