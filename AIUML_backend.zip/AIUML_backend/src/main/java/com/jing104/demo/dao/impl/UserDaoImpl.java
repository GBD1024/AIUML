package com.jing104.demo.dao.impl;

import com.jing104.demo.dao.IUserDao;
import com.jing104.demo.dao.mapper.UserMapper;
import com.jing104.demo.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserDaoImpl implements IUserDao {
    @Autowired
    private UserMapper userMapper;
    @Override
    public void register(String user_name, String md5String) {
        userMapper.add(user_name,md5String);
    }

    @Override
    public User findByUsername(String user_name) {
        return userMapper.findByUsername(user_name);
    }

    @Override
    public void updateNickname(String newNickname,Integer id) {
        userMapper.updateNickname(newNickname,id);
    }

    @Override
    public void deleteAccount(int id) {
        userMapper.deleteAccount(id);
    }

    @Override
    public void updateAvatar(String avatarUrl,Integer id) {
        userMapper.updateAvatar(avatarUrl,id);
    }

    @Override
    public void updatePwd(String newPwd,Integer id) {
        userMapper.updatePwd(newPwd,id);
    }
}
