package com.jing104.demo.service;

import com.jing104.demo.entity.Result;
import com.jing104.demo.entity.User;

import java.util.Map;

public interface IUserService {
    void register(String user_name,String password);

    User findByUsername(String user_name);


    Result login(String user_name, String password);

    Result updateNickname(Map<String, String> params);

    void deleteAccount(String token);

    void updateAvatar(String avatarUrl);

    Result updatePwd(Map<String, String> params,String token);

    String sendRandomVerificationCode(String userName);
    boolean isCodeValid(String email, String code, String s);

    Result logout(String token);

    Result NewupdatePwd(Map<String, String> params, String token);

    String sendRandomUpdatePwdCode(String email);
}
