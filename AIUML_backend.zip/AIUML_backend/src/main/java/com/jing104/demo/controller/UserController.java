package com.jing104.demo.controller;

import com.jing104.demo.entity.Result;
import com.jing104.demo.entity.User;
import com.jing104.demo.service.IUserService;
import com.jing104.demo.util.JwtUtil;
import com.jing104.demo.util.ThreadLocalUtil;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import org.hibernate.validator.constraints.URL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Map;

@RestController
@RequestMapping("/user")
@Validated

public class UserController {
    @Autowired
    private IUserService userService;

    @GetMapping("/test")
    public String test(){
        return LocalDateTime.now().toString();
    }
    @RequestMapping("/getVerificationCode")
    public Result getVerificationCode(@RequestParam @Email String userId) {
        User u = userService.findByUsername(userId);
        if (u != null) {
            return Result.error("邮箱已被占用");
        }
        String verificationCode = userService.sendRandomVerificationCode(userId);
        return Result.success();
    }

    @RequestMapping("/getUpdatePwdCode")
    public Result getUpdatePwdCode(@RequestParam @Email String userId) {
        User u = userService.findByUsername(userId);
        if (u == null) {
            return Result.error("邮箱不存在");
        }
        String verificationCode = userService.sendRandomUpdatePwdCode(userId);
        return Result.success();
    }

    @PostMapping("/register")
    public Result register(@RequestBody Map<String,String> params) {
        String userId=params.get("userId");
        String verificationCode=params.get("verifyCode");
        String password=params.get("pass");
        String re_pass=params.get("checkPass");
        User u = userService.findByUsername(userId);
        if (u != null) {
            return Result.error("邮箱已被占用");
        } else if (!password.equals(re_pass)) {
            return Result.error("密码与重复密码不一致");
        } else if (!userService.isCodeValid(userId, verificationCode, "register:")) {
            return Result.error("验证码无效");
        } else {
            userService.register(userId, password);
            return Result.success();
        }
    }
    @RequestMapping("/login")
    public Result login(@RequestBody Map<String, String> params)
    {
        String user_name=params.get("userId");
        String password=params.get("password");
        User u =userService.findByUsername(user_name);
        if(u==null)
        {

            return Result.error("邮箱未注册");
        }

        else{
            return userService.login(user_name,password);
        }

    }
    @RequestMapping("/userInfo")
    public Result<User> userInfo(/*@RequestHeader(name="Authorization") String token*/)
    {
        //重新解析
        // Map<String,Object> claimsMap= JwtUtil.parseToken(token);
        Map<String,Object> claimsMap= ThreadLocalUtil.get();
        String userName= (String) claimsMap.get("user_name");
        User user =userService.findByUsername(userName);
        return Result.success(user);
    }
//    public Result logout(/*@RequestHeader(name="Authorization") String token*/)
//    {
//        //重新解析
//        // Map<String,Object> claimsMap= JwtUtil.parseToken(token);
//        Map<String,Object> claimsMap= ThreadLocalUtil.get();
//        String userName= (String) claimsMap.get("user_name");
//        User user =userService.findByUsername(userName);
//        return Result.success(user);
//    }
    @RequestMapping("/updateNickname")
    public Result updateNickname(@RequestBody Map<String, String> params)
    {

        return userService.updateNickname(params);

    }
    @RequestMapping("/deleteAccount")
    public Result deleteAccount(@RequestHeader(name = "Authorization") String token)
    {
        userService.deleteAccount(token);
        return Result.success();
    }
    @RequestMapping("/updateAvatar")
    public Result updateAvatar(@RequestParam @URL String avatarUrl)
    {
        userService.updateAvatar(avatarUrl);
        return Result.success();
    }
    @RequestMapping("/updatePwd")
    public Result updatePwd(@RequestBody Map<String,String> params ,@RequestHeader(name = "Authorization") String token){
        return userService.updatePwd(params,token);

    }
    @RequestMapping("/newUpdatePwd")
    public Result NewupdatePwd(@RequestBody Map<String, String> params, @RequestHeader (name = "Authorization") String token) {
        return userService.NewupdatePwd(params, token);
    }
    @RequestMapping("logout")
    public Result logout(@RequestHeader(name = "Authorization") String token)
    {
        return userService.logout(token);
    }


}
