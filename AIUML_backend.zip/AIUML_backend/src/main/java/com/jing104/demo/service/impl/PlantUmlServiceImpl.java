package com.jing104.demo.service.impl;

import com.jing104.demo.service.IPlantUmlService;
import net.sourceforge.plantuml.SourceStringReader;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

@Service
public class PlantUmlServiceImpl implements IPlantUmlService {

    @Override
    public byte[] generateImage(String source) throws IOException {
        ByteArrayOutputStream png = new ByteArrayOutputStream();
        SourceStringReader reader = new SourceStringReader(source);
        reader.outputImage(png);
        return png.toByteArray();
    }
}